# NearbyBazaar Frontend

Instructions to run the frontend.